import numpy as np
import pandas as pd
from pathlib import Path

# =========================
# 설정
# =========================
BASE_DIR = Path(r"C:\Users\2512-02\Desktop\유가보조금\R\mock_dataset")
np.random.seed(42)

N_NEW_VEH = 40          # 새로 추가할 차량 수
DAYS = 14               # DTG 기간(일)
LOW_RISK_SHARE = 0.25   # 새 차량 중 LOW(주유소 집중만) 비중 (0~1)

# =========================
# 로드
# =========================
dtg  = pd.read_csv(BASE_DIR / "dtg_daily.csv")
fuel = pd.read_csv(BASE_DIR / "fuel_transaction.csv", encoding="cp949")
veh  = pd.read_csv(BASE_DIR / "vehicle_profile.csv")
stn  = pd.read_csv(BASE_DIR / "station.csv")  # 주유소는 기존 것을 사용 (없으면 삭제해도 됨)

for df in [dtg, fuel, veh, stn]:
    df.columns = df.columns.str.strip().str.replace("\ufeff", "", regex=False)

# =========================
# 유틸
# =========================
def next_id(prefix, existing_ids, width=3):
    # existing_ids: list like ["V001","V002"...]
    nums = []
    for x in existing_ids:
        if isinstance(x, str) and x.startswith(prefix):
            try:
                nums.append(int(x[len(prefix):]))
            except:
                pass
    start = (max(nums) + 1) if nums else 1
    return [f"{prefix}{i:0{width}d}" for i in range(start, start + N_NEW_VEH)]

def pick_region():
    regions = ["SEOUL", "GYEONGGI", "BUSAN", "DAEGU", "INCHEON", "GWANGJU", "DAEJEON",
               "ULSAN", "GANGWON", "CHUNGBUK", "CHUNGNAM", "JEONBUK", "JEONNAM", "GYEONGBUK", "GYEONGNAM", "JEJU"]
    return np.random.choice(regions)

def gen_vehicle_no(region):
    # 예: SEOUL12A3456 형태 비슷하게
    return f"{region}{np.random.randint(10,99)}{np.random.choice(list('ABCDE'))}{np.random.randint(1000,9999)}"

def safe_div(a,b,default=0):
    return a/b if b and b!=0 else default

# =========================
# 1) 차량(veh) 추가 생성
# =========================
existing_vehicle_ids = veh["vehicle_id"].astype(str).tolist()
new_vehicle_ids = next_id("V", existing_vehicle_ids, width=3)

# 톤급/연료/효율/탱크 용량을 “정상 범위”로 생성
ton_choices = [3,5,8,10,12]
fuel_types = ["DIESEL"]

# 대략 톤급이 올라갈수록 효율↓, 탱크용량↑
ton_to_eff = {3: 6.5, 5: 5.5, 8: 4.8, 10: 4.2, 12: 3.8}   # km/L 평균치
ton_to_tank = {3: 120, 5: 150, 8: 200, 10: 250, 12: 300}  # L

new_veh_rows = []
for vid in new_vehicle_ids:
    ton = int(np.random.choice(ton_choices))
    region = pick_region()
    base_eff = ton_to_eff[ton]
    eff = max(2.5, np.random.normal(base_eff, 0.4))  # 너무 비정상 나오지 않게
    tank = int(np.random.normal(ton_to_tank[ton], 15))
    tank = max(80, tank)

    new_veh_rows.append({
        "vehicle_id": vid,
        "vehicle_no": gen_vehicle_no(region),
        "ton_class": ton,
        "fuel_type": np.random.choice(fuel_types),
        "tank_capacity_l": tank,
        "avg_eff_km_per_l": round(eff, 2),
        "owner_type": np.random.choice(["INDIVIDUAL","COMPANY"], p=[0.6,0.4]),
        "region": region
    })

veh_new = pd.DataFrame(new_veh_rows)
veh2 = pd.concat([veh, veh_new], ignore_index=True)

# =========================
# 2) DTG(14일) 추가 생성
# =========================
# 기존 dtg의 date를 참고해서 "마지막 날짜 + 1일부터" 생성
dtg["date"] = pd.to_datetime(dtg["date"], errors="coerce")
last_date = dtg["date"].max()
if pd.isna(last_date):
    last_date = pd.Timestamp("2025-12-01")

date_range = pd.date_range(last_date + pd.Timedelta(days=1), periods=DAYS, freq="D")

new_dtg_rows = []
for row in veh_new.itertuples(index=False):
    # 하루 주행거리: 톤급 높을수록 약간 높게
    # 3t: 120~260, 12t: 180~360 정도
    base_dist = 150 + (row.ton_class * 10)
    for d in date_range:
        dist = max(0, np.random.normal(base_dist, 45))
        # 운행시간은 평균속도(40~75)로부터 역산
        avg_speed = np.clip(np.random.normal(55, 10), 30, 85)
        drive_time = safe_div(dist, avg_speed, 0)
        # 공회전 20~120분 정도
        idle = np.clip(np.random.normal(60, 25), 10, 180)

        new_dtg_rows.append({
            "vehicle_id": row.vehicle_id,
            "date": d.strftime("%Y-%m-%d"),
            "total_distance_km": round(dist, 1),
            "drive_time_hr": round(drive_time, 2),
            "avg_speed_kmh": round(avg_speed, 1),
            "idle_time_min": int(idle)
        })

dtg_new = pd.DataFrame(new_dtg_rows)
dtg2 = pd.concat([dtg.drop(columns=["date"]), dtg_new], ignore_index=True)  # date 문자열 유지(원본 맞춤)

# =========================
# 3) 주유 거래 추가 생성 (정상/저위험 위주)
# =========================
fuel["time"] = fuel["time"].astype(str)
fuel["transaction_id"] = fuel["transaction_id"].astype(str)

# 주유소 풀
station_pool = stn["station_id"].astype(str).unique().tolist()
if not station_pool:
    # station.csv가 비어있으면 임시 주유소 ID
    station_pool = [f"S{i:03d}" for i in range(1, 51)]

# 다음 transaction_id 만들기
def next_tx_ids(existing, n_add):
    # TX000001 형태면 숫자만 뽑아 증가
    nums = []
    for x in existing:
        if isinstance(x, str):
            digits = "".join([c for c in x if c.isdigit()])
            if digits:
                nums.append(int(digits))
    start = (max(nums) + 1) if nums else 1
    return [f"TX{(start+i):06d}" for i in range(n_add)]

new_fuel_rows = []

# LOW 대상 차량 일부 선정(주유소 집중 80% 이상만 걸리게)
low_n = int(N_NEW_VEH * LOW_RISK_SHARE)
low_vehicle_set = set(np.random.choice(new_vehicle_ids, size=low_n, replace=False))

for row in veh_new.itertuples(index=False):
    # 14일 총 주행거리 예상 연료량
    v_dtg = dtg_new[dtg_new["vehicle_id"] == row.vehicle_id]
    total_km = v_dtg["total_distance_km"].sum()
    expected_fuel = safe_div(total_km, row.avg_eff_km_per_l, 0)

    # 실제 주유량은 expected의 ±5% (대부분 정상)
    actual_fuel = expected_fuel * np.random.uniform(0.97, 1.05)

    # 거래 건수: 14일 동안 3~8회 정도(정상)
    refuel_cnt = int(np.random.randint(3, 9))

    # 하루 4회 이상 방지: 날짜를 넓게 분산
    chosen_dates = np.random.choice(date_range, size=refuel_cnt, replace=True)
    # 같은 날 몰리지 않도록 보정
    chosen_dates = pd.to_datetime(pd.Series(chosen_dates)).sort_values().tolist()

    # 주유소 선택 로직
    if row.vehicle_id in low_vehicle_set:
        # 주유소 집중을 0.82~0.90로 맞추되 strong flag는 안걸리게
        main_station = np.random.choice(station_pool)
        main_cnt = int(np.ceil(refuel_cnt * np.random.uniform(0.82, 0.90)))
        other_cnt = refuel_cnt - main_cnt
        stations = [main_station] * main_cnt + list(np.random.choice(
            [s for s in station_pool if s != main_station],
            size=max(1, other_cnt),
            replace=True
        ))[:other_cnt]
        np.random.shuffle(stations)
    else:
        # 정상: 집중도 0.4~0.7 정도가 되도록 2~4개 주유소 섞기
        k = int(np.random.randint(2, 5))
        st_choices = list(np.random.choice(station_pool, size=k, replace=False))
        weights = np.random.dirichlet(np.ones(k))
        # 한 곳 비중 0.8 넘지 않게 클립
        weights = np.clip(weights, 0.10, 0.60)
        weights = weights / weights.sum()
        stations = list(np.random.choice(st_choices, size=refuel_cnt, p=weights, replace=True))

    # 리터 분배: 탱크 용량 초과 방지 (각 거래는 tank의 30~70% 수준)
    # total actual_fuel을 refuel_cnt에 나눠 분배하되 각 건이 tank보다 작게
    base_parts = np.random.dirichlet(np.ones(refuel_cnt))
    liters = actual_fuel * base_parts
    liters = np.clip(liters, 5, row.tank_capacity_l * 0.7)  # 한 번에 탱크 70% 이상은 드물게
    # 클립으로 합계가 바뀌었으니 다시 스케일링(단, 탱크 초과는 막기)
    scale = safe_div(actual_fuel, liters.sum(), 1)
    liters = liters * scale
    liters = np.clip(liters, 5, row.tank_capacity_l * 0.7)
    # 마지막으로 합계 보정(오차 미세)
    diff = actual_fuel - liters.sum()
    liters[0] = max(5, min(row.tank_capacity_l * 0.7, liters[0] + diff))

    # 시간: 야간 주유 너무 많지 않게(0~1회 정도)
    night_cnt = int(np.random.choice([0,1,2], p=[0.65,0.30,0.05]))
    night_indices = set(np.random.choice(range(refuel_cnt), size=night_cnt, replace=False)) if refuel_cnt>0 else set()

    for i in range(refuel_cnt):
        dt = pd.Timestamp(chosen_dates[i])
        # 시간 랜덤
        if i in night_indices:
            hour = int(np.random.choice([23,0,1,2,3,4,5]))
        else:
            hour = int(np.random.randint(7, 22))
        minute = int(np.random.randint(0, 60))
        sec = int(np.random.randint(0, 60))
        tstamp = dt.replace(hour=hour, minute=minute, second=sec)

        unit_price = int(np.random.normal(1650, 60))  # 원/L 느낌
        unit_price = max(1200, unit_price)
        total_price = int(liters[i] * unit_price)

        new_fuel_rows.append({
            "transaction_id": None,  # 나중에 채움
            "vehicle_id": row.vehicle_id,
            "station_id": stations[i],
            "time": tstamp.strftime("%Y-%m-%d %H:%M:%S"),
            "fuel_liter": round(float(liters[i]), 2),
            "unit_price": unit_price,
            "total_price": total_price
        })

# transaction_id 채우기
tx_ids = next_tx_ids(fuel["transaction_id"].astype(str).tolist(), len(new_fuel_rows))
for r, tx in zip(new_fuel_rows, tx_ids):
    r["transaction_id"] = tx

fuel_new = pd.DataFrame(new_fuel_rows)
fuel2 = pd.concat([fuel, fuel_new], ignore_index=True)

# =========================
# 저장(원본 유지 + 새 파일로)
# =========================
out_veh  = BASE_DIR / "vehicle_profile_expanded.csv"
out_dtg  = BASE_DIR / "dtg_daily_expanded.csv"
out_fuel = BASE_DIR / "fuel_transaction_expanded.csv"

veh2.to_csv(out_veh, index=False, encoding="utf-8-sig")
dtg2.to_csv(out_dtg, index=False, encoding="utf-8-sig")
fuel2.to_csv(out_fuel, index=False, encoding="cp949")  # 기존과 동일 인코딩 유지 권장

print("저장 완료:")
print(out_veh)
print(out_dtg)
print(out_fuel)

# =========================
# (선택) 생성 후 간단 점검: LOW/NONE가 많이 나오게 되었는지
# =========================
print("\n[생성 요약]")
print("추가 차량:", len(veh_new))
print("추가 DTG 행:", len(dtg_new))
print("추가 주유 행:", len(fuel_new))
print("LOW 대상 차량 수:", len(low_vehicle_set))
